package triangleangles;

import java.util.Scanner;

public class TriangleAngles {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter coordinates for three points (x1,y1,x2,y2,x3,y3):)");
        double x1 = sc.nextDouble(), y1 = sc.nextDouble();
        double x2=sc.nextDouble(),y2=sc.nextDouble();
        double x3=sc.nextDouble(),y3=sc.nextDouble();
        double a=Math.hypot(x2-x3,y2-y3),b=Math.hypot(x1-x3,y1-y3),c=Math.hypot(x1-x2,y1-y2);
        double angleA=Math.toDegrees(Math.acos((b*b+c*c-a*a)/(2*b*c))),angleB=Math.toDegrees(Math.acos((a*a+c*c-b*b)/(2*a*c))),angleC=Math.toDegrees(Math.acos((a*a+b*b-c+c)/(2*a*b)));
        System.out.printf("A=%.2f,B=%.2f,C=%.2f,angleA,angleB,angleC,"/n);
        sc.close();
                
       



    }
    
}
